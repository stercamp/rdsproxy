import sys
import boto3
import botocore
import json
import random
import time
import os
from botocore.exceptions import ClientError
import urllib3


region_name = 'us-east-1'
conn = None

http = urllib3.PoolManager()

def handler(event, context):
    # TODO implement
    response_data = {}
    print('EventData')
    print(event['ResourceProperties'])
    try:
        if event['RequestType'] == 'Create':
            get_secret_value_response = create_secret(event, context)
            print(get_secret_value_response)
            response_data['Status'] = "SUCCESS"
            response_data['SecretArn'] = get_secret_value_response['ARN']
            response_data['SecretName'] = get_secret_value_response['Name']
            response_data['Reason'] = "Secret Created"
            get_secret_policy_response = add_resource_policy(event, context)
            print(get_secret_policy_response)
        elif event['RequestType'] == 'Update':
            get_secret_value_response = update_secret(event, context)
            print(get_secret_value_response)
            response_data['Status'] = "SUCCESS"
            response_data['SecretArn'] = get_secret_value_response['ARN']
            response_data['SecretName'] = get_secret_value_response['Name']
            response_data['Reason'] = "Secret Updated"
        elif event['RequestType'] == 'Delete':
            response_data['Status'] = "SUCCESS"
            response_data['SecretArn'] = ""
            response_data['SecretName'] = ""
            response_data['Reason'] = "Service Deleted"
    except ClientError as e:
        #print(e)
        print(e.response['Error']['Code'])
        response_data['Status'] = "FAILED"
        response_data['Reason'] = e.response['Error']['Code']

         
    send(event, context, response_data['Status'], response_data, physicalResourceId=None, noEcho=False, reason=None)
    
def create_secret(event, context):
    print("Start create_secret func")
    session = boto3.session.Session()

    client = session.client(
    	service_name='secretsmanager',
    	endpoint_url='https://secretsmanager.us-east-1.amazonaws.com'
    )
    
    response = client.create_secret(
    Name=event['ResourceProperties']['SecretName'],
    ClientRequestToken=event['ResourceProperties']['GUID'],
    Description=event['ResourceProperties']['SecretDescription'],
    SecretString=event['ResourceProperties']['SecretString'],
    Tags=[
        {
            'Key': 'GUID',
            'Value': event['ResourceProperties']['GUID']
        },
    ]
    )
    return response

def update_secret(event, context):
    print("Start update_secret func")
    session = boto3.session.Session()

    client = session.client(
    	service_name='secretsmanager',
    	endpoint_url='https://secretsmanager.us-east-1.amazonaws.com'
    )

    response = client.put_secret_value(
    SecretId=event['ResourceProperties']['SecretName'],
    SecretString=event['ResourceProperties']['SecretString']
    )

    return response

def add_resource_policy(event, context):
    print("Start add resource policy func")
    session = boto3.session.Session()

    client = session.client(
    	service_name='secretsmanager',
    	endpoint_url='https://secretsmanager.us-east-1.amazonaws.com'
    )
    
    RoleList = list(event['ResourceProperties']['Role'].split(","))

    policy_doc = {
        'Version': '2012-10-17',
        'Statement': [
            {
                'Effect': 'Allow',
                'Principal': { 'AWS': [] },
                'Action': 'secretsmanager:GetSecretValue',
                'Resource': '*'
            }
        ]
    }

    policy_doc["Statement"][0]["Principal"]["AWS"] = RoleList

    print("policy_doc")
    print(json.dumps(policy_doc))


    response = client.put_resource_policy(
    ResourcePolicy=json.dumps(policy_doc),
    SecretId=event['ResourceProperties']['SecretName']
    )

    return response

def send(event, context, responseStatus, responseData, physicalResourceId=None, noEcho=False, reason=None):
    responseUrl = event['ResponseURL']

    print(responseUrl)

    responseBody = {
        'Status' : responseStatus,
        'Reason' : reason or "See the details in CloudWatch Log Stream: {}".format(context.log_stream_name),
        'PhysicalResourceId' : physicalResourceId or context.log_stream_name,
        'StackId' : event['StackId'],
        'RequestId' : event['RequestId'],
        'LogicalResourceId' : event['LogicalResourceId'],
        'NoEcho' : noEcho,
        'Data' : responseData
    }

    json_responseBody = json.dumps(responseBody)

    print("Response body:")
    print(json_responseBody)

    headers = {
        'content-type' : '',
        'content-length' : str(len(json_responseBody))
    }

    try:
        response = http.request('PUT', responseUrl, headers=headers, body=json_responseBody)
        print("Status code:", response.status)


    except Exception as e:

        print("send(..) failed executing http.request(..):", e)